# models.py
from datetime import datetime

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Country(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    cities = db.relationship('City', back_populates='country')

class City(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    country_id = db.Column(db.Integer, db.ForeignKey('country.id'), nullable=False)
    country = db.relationship('Country', back_populates='cities')
    jobs = db.relationship('Job', back_populates='city')

# Country.cities = db.relationship('City', order_by=City.id, back_populates='country')

class Job(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    company = db.Column(db.String(100), nullable=False)
    salary = db.Column(db.Integer)
    country_id = db.Column(db.Integer, db.ForeignKey('country.id'))
    city_id = db.Column(db.Integer, db.ForeignKey('city.id'))
    # location = db.Column(db.String(100), nullable=False)
    jobtype = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    industry = db.Column(db.String(100), nullable=False)
    # description = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text)
    posted_by = db.Column(db.String(100), nullable=False)
    posting_date = db.Column(db.DateTime)
    email = db.Column(db.String(120)) 
    whatsapp_number = db.Column(db.String(15), nullable=True)
    slug = db.Column(db.String(255))
    country = db.relationship('Country')
    city = db.relationship('City', back_populates='jobs')



