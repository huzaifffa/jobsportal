from flask import Flask, render_template, redirect, url_for, flash, request, jsonify
from models import db, Job, Country, City
from forms import JobForm
from flask_wtf.csrf import generate_csrf
from datetime import datetime, timedelta 
from flask_migrate import Migrate
import slugify
from sqlalchemy import Unicode


app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///job_application.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)



migrate = Migrate(app, db)

@app.before_request
def create_tables():
    if not hasattr(app, 'tables_created'):
        db.create_all()
        app.tables_created = True

@app.route('/edit_job/<int:job_id>', methods=['GET', 'POST'])
def edit_job(job_id):
    job = Job.query.get_or_404(job_id)
    form = JobForm(obj=job)
    
    if request.method == 'POST':
        if form.validate_on_submit():
            form.populate_obj(job)
            job.posting_date = form.posting_date.data  # Ensure posting_date is handled correctly
            job.description = form.description.data
            db.session.commit()
            flash('Job updated successfully!', 'success')
            return redirect(url_for('index'))

    return render_template('edit_job.html', form=form, job=job)

@app.route('/get_cities/<int:country_id>', methods=['GET'])
def get_cities(country_id):
    cities = City.query.filter_by(country_id=country_id).all()
    city_list = [{'id': city.id, 'name': city.name} for city in cities]
    return jsonify({'cities': city_list})






@app.route('/', methods=['GET'])
def index():
    date_filter = request.args.get('date_filter', '')
    department_filter = request.args.get('department_filter', '')
    location_filter = request.args.get('location_filter', '')
    search = request.args.get('search', '')
    page = request.args.get('page', 1, type=int)  # Default to page 1

    query = Job.query

       # Count jobs for each date filter
    today = datetime.now()
    today = today - timedelta(days=1)
    one_week_ago = today - timedelta(days=7)
    two_weeks_ago = today - timedelta(days=14)

    count_today = Job.query.filter(Job.posting_date >= today).count()
    count_one_week = Job.query.filter(Job.posting_date >= one_week_ago).count()
    count_two_weeks = Job.query.filter(Job.posting_date >= two_weeks_ago).count()
    count_all = Job.query.count()

    # Apply filters
    if date_filter:
        days_ago = int(date_filter)
        filter_date = datetime.now() - timedelta(days=days_ago)
        query = query.filter(Job.posting_date >= filter_date)


    # Filter by department
    if department_filter:
        query = query.filter(Job.department == department_filter)

    # Filter by city
    if location_filter:
        query = query.join(Job.city).filter(City.name == location_filter)

    # Filter by search
    if search:
        search_filter = f"%{search}%"
        query = query.filter((Job.title.ilike(search_filter)) | (Job.description.ilike(search_filter)))

    query = query.order_by(Job.posting_date.desc())

    # Pagination
    per_page = 18
    jobs = query.paginate(page=page, per_page=per_page, error_out=False)
    total_jobs = query.count()

    # Get distinct departments from the database
    departments = Job.query.with_entities(Job.department).distinct().all()
    departments = [dep[0] for dep in departments]

    # Get distinct cities from the database
    cities = Job.query.join(Job.city).with_entities(City.name).distinct().all()
    cities = [city[0] for city in cities]

    return render_template('index.html', jobs=jobs, departments=departments, cities=cities, total_jobs=total_jobs, count_today=count_today,
        count_one_week=count_one_week,
        count_two_weeks=count_two_weeks,
        count_all=count_all)



@app.route('/all_job', methods=['GET'])
def all_jobs():
    page = request.args.get('page', 1, type=int)  # Default to page 1

    # Query for all jobs
    query = Job.query.order_by(Job.posting_date.desc())  # Adjust the ordering as needed

    # Pagination
    per_page = 18
    jobs = query.paginate(page=page, per_page=per_page, error_out=False)
    total_jobs = query.count()

    return render_template('all_job.html', jobs=jobs, total_jobs=total_jobs)



@app.route('/admin')
def admin():
    # jobs = Job.query.all()
    jobs = Job.query.order_by(Job.posting_date.desc()).all()

    return render_template('admin.html', jobs=jobs)

# @app.route('/')
# def index():
#     jobs = Job.query.all()
#     csrf_token = generate_csrf()
#     print(datetime.now())
#     return render_template('index.html', jobs=jobs, csrf_token=csrf_token)

@app.route('/post_job', methods=['GET', 'POST'])
def post_job():
    form = JobForm()

    if request.method == 'POST':
        title1 = request.form.get('title')
        slug = request.form.get('slug')
        company1 = request.form.get('company')
        salary = request.form.get('salary')
        country_id = request.form.get('country')
        city_id = request.form.get('city')
        email = request.form['email']
        whatsapp_number=form.whatsapp_number.data
        # country = request.form.get('country')
        # location = request.form.get('location')
        jobtype = request.form.get('jobtype')
        department = request.form.get('department')
        industry = request.form.get('industry')
        description1 = request.form.get('pcont')
        # posting_date = request.form.get('posting_date')
        posting_date_str = request.form.get('posting_date')
        posting_date = datetime.strptime(posting_date_str, '%Y-%m-%d')
                
        posted_by1 = 'Pak Jobs Portal'  # assuming you want a default value here
        # def generate_slug_from_title(title):
        #     return title.lower().replace(' ', '-')
        
        # if not slug:
        #     slug = generate_slug_from_title(title1)
        # slug = 'job-slug1'

  


        entry = Job(title=title1, company=company1, description=description1, posted_by=posted_by1, salary=salary, jobtype=jobtype, department=department, industry=industry, posting_date=posting_date,email=email, whatsapp_number=whatsapp_number,slug=slug,  country_id=country_id, city_id=city_id)
        db.session.add(entry)
        db.session.commit()
        flash('Job posted successfully!')
        return redirect(url_for('index'))
    
    return render_template('post_job.html', form=form)

aamir_whatsapp = 97470096250

@app.route('/job/<int:job_id>/<slug>')
def job_details(job_id, slug):
    job = Job.query.filter_by(id=job_id, slug=slug).first_or_404()
    return render_template('job_details.html', job=job, aamir_whatsapp=aamir_whatsapp)


# @app.route('/job/<int:job_id>/<slug>')
# def job_details(job_id, slug):
#     job = Job.query.filter_by(id=job_id, slug=slug).first_or_404()
#     return render_template('job_details.html', job=job, aamir_whatsapp=aamir_whatsapp)


# @app.route('/job/<int:job_id>')
# def job_details(job_id):
#     job = Job.query.get_or_404(job_id)
#     return render_template('job_details.html', job=job, aamir_whatsapp=aamir_whatsapp)

@app.route('/delete_job/<int:job_id>', methods=['POST'])
def delete_job(job_id):
    job = Job.query.get_or_404(job_id)
    db.session.delete(job)
    db.session.commit()
    flash('Job deleted successfully!')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
