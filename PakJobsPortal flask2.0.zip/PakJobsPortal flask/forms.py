# forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField, IntegerField, SelectField, DateField, EmailField
from wtforms.validators import DataRequired, Email
from models import Country
departments = [
        ('Admin jobs', 'Admin Jobs'),
        ('Engineering jobs', 'Engineering jobs'),
        ('HSE jobs', 'HSE jobs'),
        ('Finance jobs', 'Finance jobs'),
        ('HR jobs', 'HR jobs'),
        ('Procurement jobs', 'Procurement jobs'),
        ('IT jobs', 'IT jobs'),
        ('Sales & Marketing jobs', 'Sales & Marketing jobs'),
        ('Marketing jobs', 'Marketing jobs'),
        ('Business Development jobs', 'Business Development jobs'),
        ('QA/QC Jobs', 'QA/QC Jobs'),
        ('Operations jobs', 'Operations jobs'),
        ('R&D Jobs', 'R&D Jobs'),
        ('Supply Chain Jobs', 'Supply Chain Jobs'),
        ('Health Care Jobs', 'Health Care Jobs'),
        ('Other Department', 'Other Department'),
        # Add more departments as needed
    ]
class JobForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    company = StringField('Company', validators=[DataRequired()])
    salary = IntegerField('Salary', validators=[DataRequired()])
    # location = StringField('Location', validators=[DataRequired()])
    country = SelectField('Country', choices=[], coerce=int)
    city = SelectField('City', choices=[], coerce=int)
    email = EmailField('Email', validators=[DataRequired(), Email()])
    whatsapp_number = StringField('WhatsApp Number', validators=[DataRequired()])
    jobtype = StringField('Job type', validators=[DataRequired()])
    # department = StringField('Department', validators=[DataRequired()])
    department = SelectField('Department', choices=departments, validators=[DataRequired()])
    industry = SelectField('Industry',choices=[
        ('Pharma Jobs', 'Pharma Jobs'),
        ('Textile Jobs', 'Textile Jobs'),
        ('Oil and Gas Jobs', 'Oil and Gas Jobs'),
        ('Software House Jobs', 'Software House Jobs'),
        ('Freelance Jobs', 'Freelance Jobs'),
        ('Recruitment Jobs', 'Recruitment Jobs'),
        ('Ecommerce Jobs', 'Ecommerce Jobs'),
        ('Construction Jobs', 'Construction Jobs'),
        ('Energy Sector Jobs', 'Energy Sector Jobs'),
        ('Automotive Jobs', 'Automotive Jobs'),
        ('Printing & Packaging Jobs', 'Printing & Packaging Jobs'),
        ('FMCG Jobs', 'FMCG Jobs'),
        ('Hospital/Pharmacy Jobs', 'Hospital/Pharmacy Jobs'),
        ('Hotel/Resort Jobs', 'Hotel/Resort Jobs'),
        ('General Trading Jobs', 'General Trading Jobs'),
        ('Real Estate Jobs', 'Real Estate Jobs'),
        ('Telecom Jobs', 'Telecom Jobs'),
        ('Consultancy Jobs', 'Consultancy Jobs'),
        ('Other Industry', 'Other Industry'),

        # Add more departments as needed
    ],   validators=[DataRequired()])
    # industry = SelectField('Industry', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    posting_date = DateField('Posting Date', format='%Y-%m-%d', validators=[DataRequired()])
    submit = SubmitField('Post Job')

    def __init__(self, *args, **kwargs):
        super(JobForm, self).__init__(*args, **kwargs)
        self.country.choices = [(c.id, c.name) for c in Country.query.all()]

