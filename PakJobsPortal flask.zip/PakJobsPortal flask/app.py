from flask import Flask, render_template, redirect, url_for, flash, request, jsonify
from models import db, Job, Country, City
from forms import JobForm
from flask_wtf.csrf import generate_csrf
from datetime import datetime
import logging


app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///job_application.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False



# Set up basic logging
logging.basicConfig(level=logging.DEBUG)
from logging.handlers import RotatingFileHandler

db.init_app(app)

@app.before_request
def create_tables():
    if not hasattr(app, 'tables_created'):
        db.create_all()
        app.tables_created = True


@app.route('/get_cities/<int:country_id>', methods=['GET'])
def get_cities(country_id):
    cities = City.query.filter_by(country_id=country_id).all()
    city_list = [{'id': city.id, 'name': city.name} for city in cities]
    return jsonify({'cities': city_list})




@app.route('/')
def index():
    jobs = Job.query.all()
    csrf_token = generate_csrf()
    return render_template('index.html', jobs=jobs, csrf_token=csrf_token)

@app.route('/post_job', methods=['POST', 'GET'])
def post_job():
    form = JobForm()

    if request.method == 'POST' and form.validate_on_submit():
        title1 = request.form.get('title')
        company1 = request.form.get('company')
        salary = request.form.get('salary')
        country_id = request.form.get('country')
        city_id = request.form.get('city')
        jobtype = request.form.get('jobtype')
        department = request.form.get('department')
        industry = request.form.get('industry')
        description1 = request.form.get('description')
        posted_by1 = 'Pak Jobs Portal'  # assuming you want a default value here

        entry = Job(title=title1, 
                    company=company1, 
                    description=description1, 
                    posted_by=posted_by1, 
                    salary=salary, 
                    country_id=country_id, 
                    city_id=city_id, 
                    jobtype=jobtype, 
                    department=department, 
                    industry=industry
                    )

        db.session.add(entry)
        db.session.commit()
        print('Job posted successfully!')
        return redirect(url_for('index'))
    
    return render_template('post_job.html', form=form)


@app.route('/job/<int:job_id>')
def job_details(job_id):
    job = Job.query.get_or_404(job_id)
    return render_template('job_details.html', job=job)

@app.route('/delete_job/<int:job_id>', methods=['POST'])
def delete_job(job_id):
    job = Job.query.get_or_404(job_id)
    db.session.delete(job)
    db.session.commit()
    flash('Job deleted successfully!')
    return redirect(url_for('index'))

@app.route('/test_db')
def test_db():
    try:
        jobs = Job.query.all()
        return f"Found {len(jobs)} jobs in the database."
    except Exception as e:
        return str(e)
    
    

# Create a handler to write logs to a file
file_handler = RotatingFileHandler('app.log', maxBytes=10240, backupCount=10)
file_handler.setLevel(logging.INFO)  # Set log level

# Create a formatter and set it for the handler
formatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]')
file_handler.setFormatter(formatter)

# Add the handler to the app's logger
app.logger.addHandler(file_handler)

# Example log message
app.logger.info('Application startup')


if __name__ == '__main__':
    handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    app.logger.addHandler(handler)
    app.run(debug=True)
