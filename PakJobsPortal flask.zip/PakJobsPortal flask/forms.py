# forms.py

from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, SubmitField, IntegerField, SelectField, DateField
from wtforms.validators import DataRequired
from models import Country

class JobForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    company = StringField('Company', validators=[DataRequired()])
    salary = IntegerField('Salary', validators=[DataRequired()])
    country = SelectField('Country', choices=[], coerce=int)
    city = SelectField('City', choices=[], coerce=int)
    jobtype = StringField('Job type', validators=[DataRequired()])
    department = StringField('Department', validators=[DataRequired()])
    industry = StringField('Industry', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    submit = SubmitField('Post Job')

    def __init__(self, *args, **kwargs):
        super(JobForm, self).__init__(*args, **kwargs)
        self.country.choices = [(c.id, c.name) for c in Country.query.all()]

